<?php

$conn = new mysqli_connect("localhost", " root ", " ","minorproject");

if($conn->connect_error)
{
	echo "fail connection";
}
$user = $_POST["usernamesignup"];

$email = $_POST["emailsignup"];
$password = $_POST["passwordsignup"];
$password1 = $_POST["passwordsignup_confirm"];
if($password!=$password1)
	echo "Password not match";
else
{
$query = "insert into usersignup values('$user','$email','$password')";
$conn->query($query);
}

?>
