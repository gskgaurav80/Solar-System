<?php
// Receive form Post data and Saving it in variables
for ($x = 0; $x <= 10; $x++) {
   

$name = @$_POST['name'];
$email = @$_POST['email'];
$comment = @$_POST['comment'];

// Write the name of text file where data will be store
$filename = "mydata.txt";

// Marge all the variables with text in a single variable. 
$f_data= '
Name : '.$name.'
Email :  '.$email.'
Comments: '.$comment.'  
==============================================================================
';




}
header("Location:kvch.html");
$file = fopen($filename, "a");
fwrite($file,$f_data);
fclose($file);

?>