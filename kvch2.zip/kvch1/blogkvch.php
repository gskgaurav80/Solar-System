<?php
$msg="";
if (isset($_POST['upload'])) {
	$target="images/".basename($_FILES['image']['name']);
	$db= mysqli_connect("localhost","root","","photos");
	$image= $_FILES['image']['name'];
	$text=$_POST['text'];
	$user = $_POST["username"];
	$sql= "INSERT INTO images ( image,text,username) VALUES ('$image','$text','$user')";
	mysqli_query($db,$sql);
	if (move_uploaded_file($_FILES['image']['tmp_name'],$target)) {
		$msg="Image uploaded successfully";
	}
	else
	{
		$msg="There was a problem uploading image";
		}
	}

?>

<!DOCTYPE html>
<html>
<title>Solar System</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="style.css">
  
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open Sans">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
h1,h2,h3,h4,h5,h6 {font-family: "Oswald"}
body {font-family: "Open Sans"}
</style>
<style>

content{

	
	
      background-color: #f1f1f1;
      height: 100px;
	  width : 200px; 
	
}
</style>




<style>
  

 body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;
      color: #818181;
	  padding-bottom:100px;
  }
  h2 {
      font-size: 24px;
      
      color: #303030;
      font-weight: 600;
      margin-bottom: 30px;
  }
  h3 {
      font-size: 19px;
      line-height: 1.375em;
      color: #303030;
      font-weight: 400;
      margin-bottom: 30px;
  }
    /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
    .row.content {height: 250px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
    
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
    
    /* On small screens, set height to 'auto' for sidenav and grid */
    @media screen and (max-width: 767px) {
      .sidenav {
        height: auto;
        padding: 15px;
      }
      .row.content {height: auto;}
    }
  </style>


</head>
<body class="w3-light-grey">

<!-- Navigation bar with social media icons -->
<ul class="w3-navbar w3-black w3-hide-small">
  <li><a href="#"><i class="fa fa-facebook-official"></i></a></li>
  <li><a href="#"><i class="fa fa-instagram"></i></a></li>
  <li><a href="#"><i class="fa fa-snapchat"></i></a></li>
  <li><a href="#"><i class="fa fa-flickr"></i></a></li>
  <li><a href="#"><i class="fa fa-twitter"></i></a></li>
  <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
  <li class="w3-right"><a href="#"><i class="fa fa-search"></i></a></li>
   <li><a href="kvch.html"><i class="Home">Home</i></a></li>
</ul>
  
<!-- w3-content defines a container for fixed size centered content, 
and is wrapped around the whole page content, except for the footer in this example -->
<br><br>
<div class="w3-content" align="center" width="1600" height="1060">

    <h1 class="w3-xxxlarge"><b>SOLAR SYSTEM BLOGLIFE</b></h1>
    <h6>Welcome to the blog of <span class="w3-tag">Solar System</span></h6>
  </header>

  <!-- Image header>
  <header class="w3-display-container w3-wide" id="home">
    <img class="w3-image" src="img4.jpg" alt="Fashion Blog" width="1600" height="1060">
    <div class="w3-display-left w3-padding-xlarge">
      <h1 class="w3-text-white">Webwen's</h1>
      <h1 class="w3-jumbo w3-text-white w3-hide-small"><b>WEBSITE BLOG</b></h1>
      <h6><button class="w3-btn w3-white w3-padding-large w3-large w3-opacity w3-hover-opacity-off" onclick="document.getElementById('subscribe').style.display='block'">SUBSCRIBE</button></h6>
    </div>

<!--

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav">
      <a href="page1.html"><h4>WEBWEN's Blog</h4></a>
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="index.php">Home</a></li>
        
       
        <li><a href="#photos">Photos</a></li>
      </ul><br>
     
        
      </div>
    </div>-->
	<br><br><br><br><br>
<div id="content" height>
<?php
$db= mysqli_connect("localhost","root","", "photos");
$sql="SELECT * FROM images";
$result= mysqli_query($db,$sql);
while($row=mysqli_fetch_array($result)) {
	echo"<h2>".$row['username']."</h2>";
	echo"<div id='img_div'>";
	echo"<img src='images/".$row['image']."'>";
	
	echo"<h3>".$row['text']."</h3>";
	echo"</div>";
	
}
?>



<form method="post" action="blogkvch.php" enctype="multipart/form-data">
<input type="hidden" name="size" value="1000000">
<div>
<input type="file" name="image">
</div>

<div> 
<input type="username" name="username" class="form-control" placeholder="Your Username" value="username"  />
</div>
<textarea name="text" cols="60" rows="4" placeholder="Say something about your website"></textarea>
</div>
<div>
<input type="submit" name="upload" value="Upload Image">

      
</form>

</div></div>

    <div class="col-sm-9">
      <h4><small>RECENT POSTS</small></h4>
      
      <h2>I Love This</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post by Jane Dane, Sep 27, 2015.</h5>
      <h5><span class="label label-danger">Happy</span> <span class="label label-primary">love</span></h5><br>
      <p>This is the best website of Solar System..</p>
      <br><br>
      
      <h4><small>RECENT POSTS</small></h4>
      <hr>
      <h2>Don't Worry About Galaxy</h2>
      <h5><span class="glyphicon glyphicon-time"></span> Post by John Doe, Sep 24, 2015.</h5>
      <h5><span class="label label-success">like</span></h5><br>
      <p>If u want to gain some knowledge and information regarding solar system then visit this site...!!!!</p>
      <hr>
</div>


      

     


</body>
</html>